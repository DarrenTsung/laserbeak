﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using MadCompileTimeOptimizer;
using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
public class RuleSetFinalizer {

    static RuleSetFinalizer() {
        var ruleSets = RuleSet.LoadAll();
        foreach (var ruleSet in ruleSets) {
            if (ruleSet.forRemoval) {
                ruleSet.Remove();
            }
        }
    }
}