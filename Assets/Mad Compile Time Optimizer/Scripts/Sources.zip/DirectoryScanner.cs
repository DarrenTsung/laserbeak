﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class DirectoryScanner {

    #region Fields
    
    public List<Directory> rootDirs = new List<Directory>();
    public List<Directory> allDirs = new List<Directory>();

    #endregion

    #region Methods

    public void Scan() {
        Scan("Assets", null);
    }

    private void Scan(string path, Directory parent) {
        foreach (string dir in System.IO.Directory.GetDirectories(path)) {
            var directory = AddDirectory(dir, parent);
            allDirs.Add(directory);

            Scan(dir, directory);
        }
    }

    private Directory AddDirectory(string file, Directory parent) {
        var directory = new Directory(file);

        if (parent != null) {
            parent.children.Add(directory);
        } else {
            rootDirs.Add(directory);
        }

        return directory;
    }

    #endregion
}

} // namespace