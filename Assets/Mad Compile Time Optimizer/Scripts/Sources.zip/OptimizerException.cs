﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Runtime.Serialization;

public class OptimizerException : Exception {

    public OptimizerException() {
    }

    public OptimizerException(string message) : base(message) {
    }

    protected OptimizerException(SerializationInfo info, StreamingContext context) : base(info, context) {
    }

    public OptimizerException(string message, Exception innerException) : base(message, innerException) {
    }
}