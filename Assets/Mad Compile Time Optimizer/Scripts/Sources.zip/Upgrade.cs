﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.IO;
using System.Linq;
using UnityEditor;
using Debug = UnityEngine.Debug;

namespace MadCompileTimeOptimizer {

[InitializeOnLoad]
public class Upgrade {

    private const string OldRuleSet = "aa96166a507809b40896df28511e4277";
    private const string NewRuleSet = "5eb872180e6624b46b2fa8b2229cc7ac";
    private const string OldFileIdHex = "E079AF00";
    private const string NewFileIdHex = "5D667114";

    static Upgrade() {
        EditorApplication.delayCall += DoUpgrade;
    }

    [MenuItem("Tools/Do Upgrade")]
    public static void DoUpgrade() {
        var path = AssetDatabase.GUIDToAssetPath("dd9b419ee69821549bc79933423c6d37");
        var files = System.IO.Directory.GetFiles(path);

        var fromBytes = GetOldRuleSetBytes();
        var toBytes = GetNewRuleSetBytes();

        var fromFileIdBytes = GetOldFileIdBytes();
        var toFileIdBytes = GetNewFileIdBytes();

        foreach (var file in files) {
            if (IsLogFile(file)) {
                bool modified = false;

                if (IsBinaryFile(file)) {
                    /*Debug.Log("Binary");*/
                    if (UpdateBinaryLogFile(file, fromBytes, toBytes)) {
                        modified = true;
                    }

                    if (UpdateBinaryLogFile(file, fromFileIdBytes, toFileIdBytes)) {
                        modified = true;
                    }
                } else {
                    /*Debug.Log("Text");*/
                    if (UpgradeTextLogFile(file, "fileID: 11500000, guid: " + OldRuleSet, "fileID: 342976093, guid: " + NewRuleSet)) {
                        modified = true;
                    }
                }

                if (modified) {
                    AssetDatabase.ImportAsset(file, ImportAssetOptions.ForceUpdate);
                    AssetDatabase.Refresh();
                }
                
            }
        }

    }

    private static bool IsBinaryFile(string file) {
        using (var br = new BinaryReader(File.Open(file, FileMode.Open))) {
            if (br.ReadByte() == 0) {
                return true;
            }
        }

        return false;
    }

    private static bool UpgradeTextLogFile(string file, string from, string to) {
        string text = File.ReadAllText(file);

        string ntext = text;
        ntext = ntext.Replace(from, to);

        if (ntext != text) {
            File.WriteAllText(file, ntext);
            return true;
        }

        return false;
    }

    private static bool UpdateBinaryLogFile(string file, byte[] from, byte[] to) {

        /*Debug.Log("Processing file " + file);*/

        byte[] buff = new byte[from.Length];
        int position = 0;
        int found = -1;

        byte[] newBytes = null;

        using (var br = new BinaryReader(File.Open(file, FileMode.Open))) {
            var len = br.BaseStream.Length;
            newBytes = new byte[len];

            while (position < len) {
                MoveArrayLeft(ref buff);

                var b = br.ReadByte();
                newBytes[position] = b;

                buff[buff.Length - 1] = b;

                if (buff.SequenceEqual(from)) {
                    /*Debug.Log("Found at " + position);*/
                    found = position - buff.Length + 1;
                }

                position++;
            }
        }

        if (found != -1) {
            // replace
            for (int i = 0; i < from.Length; ++i) {
                newBytes[i + found] = to[i];
            }

            // write
            using (var br = new BinaryWriter(File.Open(file, FileMode.Create))) {
                br.Write(newBytes);
            }
        }

        return found != -1;
    }

    private static void MoveArrayLeft(ref byte[] arr) {
        for (int i = 1; i < arr.Length; i++) {
            arr[i - 1] = arr[i];
        }
    }

    private static bool IsLogFile(string filename) {
        return filename.Contains("log") && filename.EndsWith(".asset");
    }

    private static byte[] GetNewFileIdBytes() {
        return GetBytes(NewFileIdHex, false);
    }

    private static byte[] GetOldFileIdBytes() {
        return GetBytes(OldFileIdHex, false);
    }

    private static byte[] GetNewRuleSetBytes() {
        return GetBytes(NewRuleSet, true);
    }

    private static byte[] GetOldRuleSetBytes() {
        return GetBytes(OldRuleSet, true);
    }

    private static byte[] GetBytes(string guid, bool reverse) {
        var bytes = new byte[guid.Length / 2];
        int bytesI = 0;

        for (int i = 0; i < guid.Length; i += 2) {
            string ab = guid.Substring(i, 2);
            if (reverse) {
                var charArray = ab.ToCharArray();
                Array.Reverse(charArray);
                ab = new string(charArray);
            }

            var byteArr = StringToByteArray(ab);
            foreach (var b in byteArr) {
                bytes[bytesI++] = b;
            }
        }

        return bytes;
    }

    public static byte[] StringToByteArray(string hex) {
        var array = Enumerable.Range(0, hex.Length)
            .Where(x => x % 2 == 0)
            .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
            .ToArray();

        return array;
    }
}

} // namespace