﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

[InitializeOnLoad]
public class OldSourcesCheck : Editor {

    static OldSourcesCheck() {
        if (CanDoCheck() && SourcesExists()) {
            EditorApplication.delayCall += () => OldSourcesCheckWindow.OpenWindow();
        }
    }

    private static bool SourcesExists() {
        return !string.IsNullOrEmpty(AssetDatabase.GUIDToAssetPath("d5493b1d6b7054d40a21286f3bfce8fc"));
    }

    private static bool CanDoCheck() {
        var now = EditorApplication.timeSinceStartup;
        var then = EditorPrefs.GetFloat("LastCheck", float.MaxValue);

        EditorPrefs.SetFloat("LastCheck", (float) now);

        return now < then;
    }
}

} // namespace