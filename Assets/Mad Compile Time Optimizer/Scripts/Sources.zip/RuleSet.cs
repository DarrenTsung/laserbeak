﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class RuleSet : ScriptableObject {

    #region Public Fields

    public string ruleName;
    public string rootDirectoryGUID;

    public List<Rule> rules = new List<Rule>();

    // if set to true, rule should be removed on next unity launch
    public bool forRemoval;

    // when removing should remove empty target directories as well
    public bool forRemovalDeleteEmptyDirs;

    #endregion

    #region Private Fields

    [SerializeField]
    private bool persistent;

    #endregion

    #region Public Methods

    public static RuleSet Create(Directory directory, MoveDirectory moveDirectory) {
        var result = CreateInstance<RuleSet>();
        result.ruleName = directory.GetName();

        result.rootDirectoryGUID = directory.guid;

        var files = System.IO.Directory.GetFiles(directory.path, "*.*", SearchOption.AllDirectories);
        foreach (var file in files.Where(file => file.EndsWith(".cs") || file.EndsWith(".js"))) {
            result.CreateRule(directory, file, moveDirectory);
        }

        return result;
    }

    public ApplyState GetApplyState() {
        bool hasApplied = false;
        bool hasNotApplied = false;

        foreach (var rule in rules) {
            if (rule.IsApplied()) {
                hasApplied = true;
            } else {
                hasNotApplied = true;
            }

            if (hasApplied && !hasNotApplied) {
                return ApplyState.Partial;
            }
        }

        if (hasApplied) {
            return ApplyState.Full;
        } else {
            return ApplyState.None;
        }
    }

    public bool TryRevert() {
        bool succeed = true;
        foreach (var rule in rules.Where(rule => !rule.IsApplied())) {
            if (!rule.TryRevert()) {
                succeed = false;
            }
        }

        return succeed;
    }

    public void Apply(Action<int, int> progressCallback = null) {
        int ruleNum = 0;
        foreach (var rule in rules.Where(rule => !rule.IsApplied())) {
            ruleNum++;
            if (progressCallback != null) {
                progressCallback(ruleNum, rules.Count);
            }

            rule.Apply();
        }
    }

    public void PrepareRevert() {
        foreach (var rule in rules.Where(rule => rule.IsApplied())) {
            rule.PrepareRevert();
        }
    }

    public void Revert(bool removeEmptyDirs, Action<int, int> progressCallback = null) {
        int ruleNum = 0;

        foreach (var rule in rules.Where(rule => rule.IsApplied())) {
            ruleNum++;
            if (progressCallback != null) {
                progressCallback(ruleNum, rules.Count);
            }

            rule.Revert();
        }
    }

    public void Save(bool refresh = true) {
        if (!persistent) {
            persistent = true;

            var resourcesPath = AssetDatabase.GUIDToAssetPath("dd9b419ee69821549bc79933423c6d37");
            if (string.IsNullOrEmpty(resourcesPath)) {
                Debug.LogError("Resources directory not found. Have you removed it? Please try removing the MCTO directory and importing it again.");
            }

            var path = AssetDatabase.GenerateUniqueAssetPath(resourcesPath + "/" + ruleName + "-log.asset");

            AssetDatabase.CreateAsset(this, path);
            AssetDatabase.SaveAssets();
            if (refresh) {
                AssetDatabase.Refresh();
            }
        } else {
            EditorUtility.SetDirty(this);
        }
        
    }

    public void Remove(bool refresh = true) {
        if (persistent) {
            if (forRemovalDeleteEmptyDirs) {
                RemoveEmptyTargetDirs();
            }

            var path = AssetDatabase.GetAssetPath(this);
            AssetDatabase.MoveAssetToTrash(path);

            if (refresh) {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
        }
    }

    private void RemoveEmptyTargetDirs() {
        Debug.Log("Removing empty dirs for " + ruleName);

        foreach (var rule in rules) {
            rule.RemoveEmptyTargetDirs();
        }
    }

    public static RuleSet[] LoadAll() {
        return Resources.LoadAll<RuleSet>("");
    }

    #endregion

    #region Private Methods

    private void CreateRule(Directory directory, string path, MoveDirectory moveDirectory) {
        var rule = new Rule();

        rule.sourcePath = path;
        rule.sourceGUID = AssetDatabase.AssetPathToGUID(rule.sourcePath);

        if (InEditor(path)) {
            rule.targetPath = Path.Combine(Path.Combine("Assets", GetDirectoryName(moveDirectory)), "Editor");
        } else {
            rule.targetPath = Path.Combine("Assets", GetDirectoryName(moveDirectory));
        }

        rule.targetPath = Path.Combine(rule.targetPath, directory.GetRelativePath(path));

        rules.Add(rule);
    }

    private string GetDirectoryName(MoveDirectory moveDirectory) {
        switch (moveDirectory) {
            case MoveDirectory.StandardAssets:
                return "Standard Assets";
            case MoveDirectory.Plugins:
                return "Plugins";
            default:
                throw new ArgumentOutOfRangeException("moveDirectory");
        }
    }

    private bool InEditor(string path) {
        var parts = new List<string>(path.Split(Path.DirectorySeparatorChar));
        return parts.Contains("Editor");
    }

    #endregion

    #region Inner and Anonymous Classes

    [Serializable]
    public class Rule {
        public string sourcePath;
        public string sourceGUID;

        public string targetPath;

        public override string ToString() {
            return string.Format("SourcePath: {0}, SourceGuid: {1}, TargetPath: {2}", sourcePath, sourceGUID, targetPath);
        }

        public void Apply() {
            if (IsApplied()) {
                throw new OptimizerException("This ruleset is already applied");
            }

            BuildUpDirectories(targetPath);

            string error = MoveAsset(sourcePath, targetPath);

            if (!string.IsNullOrEmpty(error)) {
                throw new OptimizerException("Error while moving asset: " + error);
            }
        }

        public void PrepareRevert() {
            BuildUpDirectories(sourcePath);
        }

        public void Revert() {
            if (!IsApplied()) {
                throw new OptimizerException("Cannot revert rule that is not applied.");
            }

            
            string error = AssetDatabase.MoveAsset(targetPath, sourcePath);
            if (!string.IsNullOrEmpty(error)) {
                throw new OptimizerException("Error while moving asset: " + error);
            }
        }

        private string MoveAsset(string from, string to) {
            if (CanMoveNatively(from, to)) {
                NativeMove(from, to);
                return "";
            } else {
                return AssetDatabase.MoveAsset(from, to);
            }
        }

        private bool CanMoveNatively(string @from, string to) {
            string metaFile = @from + ".meta";
            return File.Exists(metaFile);
        }

        private void NativeMove(string @from, string to) {
            File.Move(@from, to);
            File.Move(@from + ".meta", to + ".meta");
        }

        private bool IsDirectoryEmpty(string dirPath) {
            var entries = System.IO.Directory.GetFileSystemEntries(dirPath);
//            foreach (var entry in entries) {
//                Debug.Log(entry);
//            }
            return entries.Length == 0;
        }

        public bool TryRevert() {
            if (!IsApplied()) {
                Debug.LogError("File " + sourcePath + " cannot be found.");
                return false;
            }

            string error = AssetDatabase.ValidateMoveAsset(targetPath, sourcePath);
            if (!string.IsNullOrEmpty(error)) {
                Debug.LogWarning("Problem found: " + error);
                return false;
            }

            return true;
        }

        public bool IsApplied() {
            return File.Exists(targetPath);
        }

        private void BuildUpDirectories(string path) {
            path = Path.GetDirectoryName(path);
            var parts = path.Split(Path.DirectorySeparatorChar);

            string p = null;

            foreach (var part in parts) {
                if (!string.IsNullOrEmpty(p)) {
                    string newPath = Path.Combine(p, part);
                    if (!System.IO.Directory.Exists(newPath)) {
                        //Debug.Log("Not exists: " + newPath);
                        string guid = AssetDatabase.CreateFolder(p, part);
                        //Debug.Log("Create folder: " + p + ", " + part);
                        if (string.IsNullOrEmpty(guid)) {
                            throw new OptimizerException("Cannot create folder " + newPath);
                        }
                    }

                    p = newPath;

                } else {
                    p = part;
                }
            }
        }

        public void RemoveEmptyTargetDirs() {
            var parts = targetPath.Split(Path.DirectorySeparatorChar);

            for (int i = parts.Length - 1; i >= 0; i--) {
                var sb = new StringBuilder();
                for (int j = 0; j <= i; j++) {
                    if (sb.Length != 0) {
                        sb.Append(Path.DirectorySeparatorChar);
                    }
                    sb.Append(parts[j]);
                }

                var dir = sb.ToString();
                if (System.IO.Directory.Exists(dir) && IsDirectoryEmpty(dir)) {
                    AssetDatabase.DeleteAsset(dir);
                }
            }
        }
    }

    public enum ApplyState {
        None,
        Partial,
        Full,
    }

    public enum MoveDirectory {
        StandardAssets,
        Plugins,
    }

    #endregion
}

} // namespace