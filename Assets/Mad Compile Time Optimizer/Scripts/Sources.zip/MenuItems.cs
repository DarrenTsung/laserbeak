﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class MenuItems {

    [MenuItem("Tools/Mad Compile Time Optimizer/Optimize...", false, 1)]
    public static void OptimizeWizard() {
        MadCompileTimeOptimizer.OptimizeWizard.OpenWizard();
    }

    [MenuItem("Tools/Mad Compile Time Optimizer/Revert...", false, 2)]
    public static void RevertWizard() {
        MadCompileTimeOptimizer.RevertWizard.OpenWizard();
    }

    [MenuItem("Tools/Mad Compile Time Optimizer/Compile Timer", false, 30)]
    public static void CompileTimer() {
        MadPixelMachine.CompileTimer.Open();
    }

}

} // namespace