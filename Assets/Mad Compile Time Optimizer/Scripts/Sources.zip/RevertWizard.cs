﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class RevertWizard : EditorWindow {
    #region Public Fields
    #endregion

    #region Private Fields

    private List<RuleSet> ruleSets = new List<RuleSet>();

    private Vector2 scrollPosition;

    private HashSet<RuleSet> selectedRules = new HashSet<RuleSet>();

    private bool issuesFound;
    private bool force;

    private bool removeEmptyDirectories {
        get { return EditorPrefs.GetBool("Remove Empty Dirs", true); }
        set { EditorPrefs.SetBool("Remove Empty Dirs", value);}
    }

    #endregion

    #region Public Methods

    public static void OpenWizard() {
        GetWindow<RevertWizard>(false, "Revert", true);
    }

    #endregion

    #region Unity Methods

    void OnEnable() {
        ruleSets.Clear();
        ruleSets.AddRange(RuleSet.LoadAll());
        ruleSets.Sort((a, b) => System.String.Compare(a.ruleName, b.ruleName, System.StringComparison.Ordinal));
    }

    void OnGUI() {
        if (ruleSets.Count == 0) {
            GUILayout.Label("No optimize logs found. Maybe you want to optimize your project first?");
            return;
        }

        GUILayout.Label("Choose assets to revert", "HeaderLabel");

        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
        foreach (var ruleSet in ruleSets) {
            GUIRuleSet(ruleSet);
        }
        EditorGUILayout.EndScrollView();

        EditorGUILayout.Space();

        if (issuesFound) {
            force = EditorGUILayout.ToggleLeft("Force", force);
        }

        EditorGUILayout.Space();

        GUILayout.Label("Options", "HeaderLabel");

        EditorGUI.indentLevel++;

        removeEmptyDirectories = EditorGUILayout.ToggleLeft("Remove Empty Directories", removeEmptyDirectories);

        EditorGUI.indentLevel--;

        EditorGUILayout.Space();

        GUI.enabled = selectedRules.Count > 0;
        if (GUILayout.Button("Revert")) {
            RevertFirstPass();
        }

        GUI.enabled = true;

        EditorGUILayout.Space();

        EditorGUILayout.HelpBox("Unity Editor will be restarted after this operation.", MessageType.Warning);
    }

    private void RevertFirstPass() {
        foreach (var rule in selectedRules) {
            rule.PrepareRevert();
        }

        EditorApplication.delayCall += RevertSecondPass;
    }

    private void RevertSecondPass() {

        if (!force) {
            foreach (var rule in selectedRules) {
                EditorUtility.DisplayProgressBar("Reverting...", "Checking if " + rule.ruleName + " can be reverted", 0);
                if (!rule.TryRevert()) {
                    issuesFound = true;
                }
                EditorUtility.ClearProgressBar();
            }

            if (issuesFound) {
                EditorUtility.DisplayDialog(
                    "Issues found",
                    "There will be issues with reverting some assets. " +
                    "Most probably because some scripts has been moved or removed. " +
                    "Please review the console logs.\n" +
                    "\n" +
                    "If you still want to apply, please enable 'Force' option.", "OK");
                return;
            }
        }

        if (!EditorApplication.SaveCurrentSceneIfUserWantsTo()) {
            return;
        }

        EditorApplication.NewScene();

        bool hasError = false;
        AssetDatabase.StartAssetEditing();
        foreach (var rule in selectedRules) {
            try {
                EditorUtility.DisplayProgressBar("Reverting " + rule.ruleName, "...", 0);

                rule.Revert(removeEmptyDirectories, (current, total) => {
                    float progress = current / (float) total;
                    EditorUtility.DisplayProgressBar(
                        "Reverting " + rule.ruleName,
                        string.Format("Reverting script file {0} of {1}", current, total),
                        progress);
                });

                EditorUtility.ClearProgressBar();
                rule.forRemoval = true;
                rule.forRemovalDeleteEmptyDirs = removeEmptyDirectories;
                EditorUtility.SetDirty(rule);
                //rule.Remove(true);
            } catch (IOException e) {
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Error while moving",
                    "There was an exception while moving files. I will try to undo the operation now.\n\n" + e.Message, "OK");
                hasError = true;

                try {
                    rule.Apply((current, total) => {
                        float progress = current / (float) total;
                        EditorUtility.DisplayProgressBar(
                            "Undoing " + rule.ruleName,
                            string.Format("Undoing script file {0} of {1}", current, total),
                            progress);
                    });
                    EditorUtility.ClearProgressBar();
                } catch (IOException e2) {
                    EditorUtility.DisplayDialog("Error while undoing",
                                        "There was an exception while undoing things. Well... Things are looking really bad now :-( " +
                                        "Try to remove 3rd-party assets and import these again.\n\n" + e2.Message, "Really?!");
                } finally {
                    EditorUtility.ClearProgressBar();
                }

                break; // do not continue the loop after the error

            } finally {
                EditorUtility.ClearProgressBar();
            }
            
        }
        AssetDatabase.StopAssetEditing();


        if (!hasError) {
            EditorUtility.DisplayDialog("Revert Done!", "Revert Done! Unity will now restart.", "OK");
        } else {
            EditorUtility.DisplayDialog("Done with errors.", "Not all scripts has been reverted. Unity will now restart.", "OK");
        }
        EditorApplication.OpenProject(System.IO.Directory.GetCurrentDirectory());
        Close();
    }

    private void GUIRuleSet(RuleSet ruleSet) {
        EditorGUI.BeginChangeCheck();
        bool selected = EditorGUILayout.ToggleLeft(ruleSet.ruleName, IsSelected(ruleSet));
        if (EditorGUI.EndChangeCheck()) {
            SetSelected(ruleSet, selected);
        }
    }

    private bool IsSelected(RuleSet ruleSet) {
        return selectedRules.Contains(ruleSet);
    }

    private void SetSelected(RuleSet ruleSet, bool val) {
        if (val) {
            selectedRules.Add(ruleSet);
        } else {
            selectedRules.Remove(ruleSet);
        }
    }

    #endregion

    #region Private Methods
    #endregion

    #region Inner and Anonymous Classes
    #endregion
}

} // namespace