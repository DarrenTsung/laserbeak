﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class OldSourcesCheckWindow : EditorWindow {
    private Texture2D infoTexture;

    #region Public Fields
    #endregion

    #region Private Fields
    #endregion

    #region Public Methods

    public static void OpenWindow() {
        GetWindow<OldSourcesCheckWindow>(false, "Upgrade", true);
    }

    #endregion

    #region Unity Methods

    void OnEnable() {
        var path = AssetDatabase.GUIDToAssetPath("618b206da26caa348873d20cc67644ad");
        infoTexture = (Texture2D) AssetDatabase.LoadAssetAtPath(path, typeof(Texture2D));
        minSize = new Vector2(355, 456);
    }

    void OnGUI() {
        EditorGUILayout.HelpBox("This version of Mad Compile Time Optimizer uses DLL instead of raw sources to provide stability. " +
                                "Please remove all old sources files from your project directory. After doing so " +
                                "PLEASE RESTART YOUR UNITY EDITOR.", MessageType.Warning);

        GUILayout.Label(infoTexture);

        GUILayout.FlexibleSpace();

        if (GUILayout.Button("Close")) {
            Close();
        }
    }

    #endregion

    #region Private Methods
    #endregion

    #region Inner and Anonymous Classes
    #endregion
}

} // namespace