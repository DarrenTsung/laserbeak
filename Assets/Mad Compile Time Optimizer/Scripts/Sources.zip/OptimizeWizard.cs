﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class OptimizeWizard : EditorWindow {

    #region Public Fields
    #endregion

    #region Private Fields

    private DirectoryScanner scanner;
    private Vector2 scrollPosition;

    public HashSet<Directory> selected = new HashSet<Directory>();
    public HashSet<string> expanded = new HashSet<string>();

    private RuleSet.MoveDirectory moveDirectory {
        get { return (RuleSet.MoveDirectory) EditorPrefs.GetInt("Move Directory", (int) default(RuleSet.MoveDirectory)); }
        set { EditorPrefs.SetInt("Move Directory", (int) value); }
    }

    #endregion

    #region Public Methods

    public static void OpenWizard() {
        GetWindow<OptimizeWizard>(false, "Optimize", true);
    }

    #endregion

    #region Unity Methods

    void OnEnable() {
        if (scanner == null) {
            Rescan();
            LoadSelected();
        }
    }

    private void Rescan() {
        scanner = new DirectoryScanner();
        scanner.Scan();
    }

    void OnGUI() {
        if (scanner == null) {
            return;
        }

        GUILayout.Label("Choose Assets", "HeaderLabel");

        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

        foreach (var directory in scanner.rootDirs) {
            GUIDirectory(directory);
        }

        EditorGUILayout.EndScrollView();

        EditorGUILayout.Space();

        GUILayout.Label("Options", "HeaderLabel");
        EditorGUI.indentLevel++;
        moveDirectory = (RuleSet.MoveDirectory) EditorGUILayout.EnumPopup("Move Directory", moveDirectory);
        EditorGUI.indentLevel--;

        EditorGUILayout.Space();

        GUI.enabled = selected.Count > 0;
        if (GUILayout.Button("Optimize")) {
            //AssetDatabase.StartAssetEditing();

            foreach (var directory in selected) {
                var ruleSet = RuleSet.Create(directory, moveDirectory);
                ruleSet.Save(false);


                try {
                    EditorUtility.DisplayProgressBar("Optimizing " + ruleSet.ruleName, "...", 0);
                    ruleSet.Apply((current, total) => {
                        float progress = current / (float) total;
                        EditorUtility.DisplayProgressBar(
                            "Optimizing " + ruleSet.ruleName,
                            string.Format("Optimizing script file {0} of {1}", current, total),
                            progress);
                    });

                    EditorUtility.ClearProgressBar();
                } catch (IOException e) {
                    EditorUtility.ClearProgressBar();

                    EditorUtility.DisplayDialog("Error while moving",
                "There was an exception while moving files. I will try to undo the operation now.\n\n" + e.Message, "OK");

                    try {
                        ruleSet.Revert(false, (current, total) => {
                            float progress = current / (float)total;
                            EditorUtility.DisplayProgressBar(
                                "Undoing " + ruleSet.ruleName,
                                string.Format("Undoing script file {0} of {1}", current, total),
                                progress);
                        });
                        EditorUtility.ClearProgressBar();
                    } catch (IOException e2) {
                        EditorUtility.DisplayDialog("Error while undoing",
                                            "There was an exception while undoing things. Well... Things are looking really bad now :-( " +
                                            "Try to remove 3rd-party assets and import these again.\n\n" + e2.Message, "Really?!");
                    } finally {
                        EditorUtility.ClearProgressBar();
                    }

                    break; // do not continue the loop after the error
                } finally {
                    EditorUtility.ClearProgressBar();
                }
            }

            //AssetDatabase.StopAssetEditing();

            AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("Optimization Done!", "Optimization Done!", "OK");
            Rescan();
        }
        GUI.enabled = true;
    }

    private int indent;

    private void GUIDirectory(Directory directory) {
        GUI.enabled = !directory.IsOptimized() && !directory.IsForbidden() && directory.ContainsScriptFiles();

        string comment = "";
        Color color = Color.white;

        if (directory.IsOptimized()) {
            comment = "Optimized";
            color = Color.green;
        } else if (directory.IsForbidden()) {
            comment = "Forbidden";
            color = Color.cyan;
        } else if (!directory.ContainsScriptFiles()) {
            comment = "Nothing to optimize";
            color = Color.gray;
        }

        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(5 + 18 * indent);
        EditorGUI.BeginChangeCheck();
        bool expanded = false;
        if (directory.children.Count > 0) {
            EditorGUIUtility.labelWidth = 1;
            EditorGUIUtility.fieldWidth = 10;
            expanded = EditorGUILayout.Foldout(IsExpanded(directory), "");
            EditorGUIUtility.fieldWidth = 0;
            EditorGUIUtility.labelWidth = 0;
        } else {
            GUILayout.Space(14);
        }
        if (EditorGUI.EndChangeCheck() && GUI.enabled) {
            SetExpanded(directory, expanded);
        }

        EditorGUI.BeginChangeCheck();
        EditorGUI.showMixedValue = IsChildSelected(directory) && !IsSelected(directory);
        bool state = EditorGUILayout.ToggleLeft(directory.GetName(), IsSelected(directory));
        EditorGUI.showMixedValue = false;
        if (EditorGUI.EndChangeCheck()) {
            SetSelected(directory, state);
        }

        GUI.enabled = true;

        GUILayout.FlexibleSpace();
        GUI.color = color;
        GUILayout.Label(comment);
        GUI.color = Color.white;
        EditorGUILayout.EndHorizontal();

        if (expanded) {
            indent++;
            foreach (var child in directory.children) {
                GUIDirectory(child);
            }
            indent--;
        }

        
    }

    private bool IsSelected(Directory directory) {
        return selected.Contains(directory);
    }

    private bool IsChildSelected(Directory directory) {
        foreach (var child in directory.children) {
            if (IsSelected(child)) {
                return true;
            }

            if (IsChildSelected(child)) {
                return true;
            }
        }

        return false;
    }

    public void SetSelected(Directory directory, bool val) {
        if (val) {
            selected.Add(directory);
        } else {
            selected.Remove(directory);
        }

        SaveSelected();
    }

    private bool IsExpanded(Directory directory) {
        return expanded.Contains(directory.path);
    }

    public void SetExpanded(Directory directory, bool val) {
        if (val) {
            expanded.Add(directory.path);
        } else {
            expanded.Remove(directory.path);
        }
    }

    #endregion

    #region Private Methods

    private void SaveSelected() {
        var sb = new StringBuilder();
        foreach (var s in selected) {
            if (sb.Length > 0) {
                sb.Append(",");
            }
            sb.Append(s.guid);
        }

        EditorPrefs.SetString("Selected", sb.ToString());
    }

    private void LoadSelected() {
        selected.Clear();

        var dict = new Dictionary<string, Directory>();
        foreach (var directory in scanner.allDirs) {
            dict.Add(directory.guid, directory);
        }


        var str = EditorPrefs.GetString("Selected", "");
        if (string.IsNullOrEmpty(str)) {
            return;
        }

        foreach (var guid in str.Split(',')) {
            if (dict.ContainsKey(guid)) {
                var directory = dict[guid];
                if (!directory.IsOptimized() && !directory.IsForbidden()) {
                    selected.Add(directory);
                }
            }
        }
    }

    #endregion

    #region Inner and Anonymous Classes
    #endregion
}

} // namespace