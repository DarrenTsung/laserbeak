﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using UnityEngine;

namespace MadCompileTimeOptimizer {

public class Optimizer {

    #region Public Fields
    #endregion

    #region Private Fields
    #endregion

    #region Public Methods
    #endregion

    #region Unity Methods

    void Start() {
    }

    void Update() {
    }

    #endregion

    #region Private Methods
    #endregion

    #region Inner and Anonymous Classes
    #endregion
}

} // namespace