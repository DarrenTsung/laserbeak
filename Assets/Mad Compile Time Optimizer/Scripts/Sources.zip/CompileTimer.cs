﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using UnityEditor;
using UnityEngine;

namespace MadPixelMachine {

public class CompileTimer : EditorWindow {

    public List<int> compileTimes = new List<int>();

    private bool compiling;

    private Vector2 scrollPosition;

    private long startTime {
        get { return long.Parse(EditorPrefs.GetString("startTime", "0")); }
        set { EditorPrefs.SetString("startTime", value.ToString(CultureInfo.InvariantCulture)); }
    }

    //[MenuItem("Window/Compile Timer")]
    public static void Open() {
        EditorWindow.GetWindow<CompileTimer>(false, "Compile Timer", true);
    }

    
    void OnGUI() {
        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
        foreach (var compileTime in compileTimes) {
            GUILayout.Label(compileTime + " ms");
        }
        
        EditorGUILayout.Space();
        
        if (compiling) {
            GUILayout.Label("Now Compiling...");
        }

        EditorGUILayout.Space();

        if (GUILayout.Button("Reset")) {
            compileTimes.Clear();
        }

        EditorGUILayout.EndScrollView();
    }

    void OnEnable() {
        EditorApplication.update += OnEditorUpdate;
    }

    void OnDisable() {
        EditorApplication.update -= OnEditorUpdate;
    }

    private void OnEditorUpdate() {
        if (CompilationStarted()) {
            compiling = true;
            startTime = GetMilliseconds();
        } else if (CompilationEnded()) {
            compiling = false;
            long time = GetMilliseconds() - startTime;
            compileTimes.Add((int) time);
            Repaint();
        }
    }

    private bool CompilationEnded() {
        return compiling && !EditorApplication.isCompiling;
    }

    private bool CompilationStarted() {
        return !compiling && EditorApplication.isCompiling;
    }

    private long GetMilliseconds() {
        long milliseconds = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
        return milliseconds;
    }
}

} // namespace