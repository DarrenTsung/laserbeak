﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using UnityEngine;

public class OptimizeData : MonoBehaviour {

    #region Public Fields
    #endregion

    #region Private Fields
    #endregion

    #region Public Methods
    #endregion

    #region Unity Methods

    void Start() {
    }

    void Update() {
    }

    #endregion

    #region Private Methods
    #endregion

    #region Inner and Anonymous Classes
    #endregion
}