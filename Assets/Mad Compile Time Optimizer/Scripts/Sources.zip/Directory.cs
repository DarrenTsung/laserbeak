﻿/*
* Copyright (c) Mad Pixel Machine
* http://www.madpixelmachine.com/
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace MadCompileTimeOptimizer {

public class Directory {

    #region Public Fields

    public string path;
    public string guid;

    public List<Directory> children = new List<Directory>();

    public Directory(string file) {
        path = file;
        guid = AssetDatabase.AssetPathToGUID(path);
    }

    #endregion

    #region Private Fields

    private bool isOptimized;
    private bool isOptimizedCached;

    private bool containsScriptFiles;
    private bool containsScriptFilesCached;

    #endregion

    #region Public Methods

    public string GetName() {
        return Path.GetFileName(path);
    }

    public string GetRelativePath(string anotherPath) {
        return MakeRelativePath(path, anotherPath);
    }

    public bool IsOptimized() {
        if (!isOptimizedCached) {
            foreach (var ruleSet in RuleSet.LoadAll()) {
                if (ruleSet.rootDirectoryGUID == guid) {
                    isOptimized = true;
                    break;
                }
            }

            isOptimizedCached = true;
        }

        return isOptimized;
    }

    public bool IsForbidden() {
        if (path == Path.Combine("Assets", "Plugins")) {
            return true;
        }

        if (path == Path.Combine("Assets", "Standard Assets")) {
            return true;
        }

        if (guid == "a1284937824d5294980d5dac2ecac4e2") { // Mad Compile Time Optimizer GUID
            return true;
        }

        return false;
    }

    public bool ContainsScriptFiles() {
        if (!containsScriptFilesCached) {
            var files = System.IO.Directory.GetFiles(path, "*.*", SearchOption.AllDirectories);
            var f = files.FirstOrDefault(file => file.EndsWith(".cs") || file.EndsWith(".js"));
            if (f != null) {
                containsScriptFiles = true;
            }

            containsScriptFilesCached = true;
        }

        return containsScriptFiles;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Creates a relative path from one file or folder to another.
    /// </summary>
    /// <param name="fromPath">Contains the directory that defines the start of the relative path.</param>
    /// <param name="toPath">Contains the path that defines the endpoint of the relative path.</param>
    /// <returns>The relative path from the start directory to the end path.</returns>
    /// <exception cref="ArgumentNullException"></exception>
    /// <exception cref="UriFormatException"></exception>
    /// <exception cref="InvalidOperationException"></exception>
    private String MakeRelativePath(String fromPath, String toPath) {
        if (String.IsNullOrEmpty(fromPath)) throw new ArgumentNullException("fromPath");
        if (String.IsNullOrEmpty(toPath)) throw new ArgumentNullException("toPath");

        fromPath = Path.GetFullPath(fromPath);
        toPath = Path.GetFullPath(toPath);

        Uri fromUri = new Uri(fromPath);
        Uri toUri = new Uri(toPath);

        if (fromUri.Scheme != toUri.Scheme) { return toPath; } // path can't be made relative.

        Uri relativeUri = fromUri.MakeRelativeUri(toUri);
        String relativePath = Uri.UnescapeDataString(relativeUri.ToString());

        if (toUri.Scheme.ToUpperInvariant() == "FILE") {
            relativePath = relativePath.Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);
        }

        return relativePath;
    }

    #endregion

    #region Inner and Anonymous Classes
    #endregion
}

} // namespace